package com.aro.musicplayer

interface ItemClicked {

    fun itemClicked(position : Int)

}