package com.aro.musicplayer

import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_music_player.*
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class MusicPlayerActivity : AppCompatActivity(), ItemClicked {
    override fun itemClicked(position: Int) {
        stop()
        this.currPosition = position
        play(position)
    }

    private lateinit var musicList : MutableList<Music>
    private lateinit var linearLayoutManager : LinearLayoutManager
    private lateinit var adapter : MusicListAdapter
    private var currPosition : Int = 0
    private var isPlaying = false
    private var isShuffling = false
    private var mediaPlayer : MediaPlayer? = null
    private var randomPosition : Int = 0

    companion object{
        private const val  REQUEST_CODE_READ_EXTERNAL_STORAGE = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)

        musicList = mutableListOf()


        if(Build.VERSION.SDK_INT >= 23) {
            checkPermissions()
        }

        play_button.setOnClickListener{
            play(currPosition)
        }

        next_button.setOnClickListener(){
            next()
        }

        previous_button.setOnClickListener(){
            previous()
        }

        shuffle_button.setOnClickListener(){
            shufflePlay(randomPosition)
        }



        seek_bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser){
                    mediaPlayer?.seekTo( progress * 1000)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    fun next (){
        if(isShuffling){
            stop()
            randomPosition = Random.nextInt(0, musicList.size)
            shufflePlay(randomPosition)
        } else if(currPosition < musicList.size - 1) {
            stop()
            currPosition += 1
            play(currPosition)
        } else {
            stop()
            play(currPosition)
        }
    }

    fun previous (){
        if(isShuffling){
            stop()
            randomPosition = Random.nextInt(0, musicList.size)
            shufflePlay(randomPosition)
        } else if(currPosition > 0) {
            stop()
            currPosition -= 1
            play(currPosition)
        } else {
            stop()
            play(currPosition)
        }
    }

    fun stop (){
        mediaPlayer?.stop()
        isPlaying = false
        isShuffling = false
        play_button.setImageDrawable(resources.getDrawable(R.drawable.ic_play_arrow, null))
        shuffle_button.setImageDrawable(resources.getDrawable(R.drawable.ic_shuffle, null))
        song_title_text_view_in_card_view.text = " "

    }



    fun shufflePlay(currPosition : Int){



        if(!isShuffling){

            stop()

            randomPosition = Random.nextInt(0, musicList.size)

            shuffle_button.setImageDrawable(resources.getDrawable(R.drawable.ic_stop, null))
            isShuffling= true
            mediaPlayer = MediaPlayer().apply {

                setAudioStreamType(AudioManager.STREAM_MUSIC)
                setDataSource(this@MusicPlayerActivity, Uri.parse(musicList[randomPosition].songUri))
                prepare()
                start()
                song_title_text_view_in_card_view.text = musicList[randomPosition].songName

            }

            val mHandler = Handler()

            this@MusicPlayerActivity.runOnUiThread(object : Runnable{
                override fun run() {
                    val playerPosition = mediaPlayer?.currentPosition!! / 1000
                    val totalDuration = mediaPlayer?.duration!! / 1000

                    seek_bar.max = totalDuration
                    seek_bar.progress = playerPosition


                    time_elapsed_text_view.text = timerFormat(playerPosition.toLong())
                    time_remaining_text_view.text = timerFormat((totalDuration - playerPosition).toLong())

                    mHandler.postDelayed(this, 1000)

                    if (playerPosition == totalDuration){

                        next()

                    }
                }
            })

        }else{

            stop()
        }
    }

    fun play(currPosition : Int){


        if(!isPlaying){

            stop()

            play_button.setImageDrawable(resources.getDrawable(R.drawable.ic_stop, null))
            isPlaying = true
            mediaPlayer = MediaPlayer().apply {

                setAudioStreamType(AudioManager.STREAM_MUSIC)
                setDataSource(this@MusicPlayerActivity, Uri.parse(musicList[currPosition].songUri))
                prepare()
                start()
                song_title_text_view_in_card_view.text = musicList[currPosition].songName

            }

            val mHandler = Handler()


            this@MusicPlayerActivity.runOnUiThread(object : Runnable{
                override fun run() {
                    val playerPosition = mediaPlayer?.currentPosition!! / 1000
                    val totalDuration = mediaPlayer?.duration!! / 1000

                    seek_bar.max = totalDuration
                    seek_bar.progress = playerPosition


                    time_elapsed_text_view.text = timerFormat(playerPosition.toLong())
                    time_remaining_text_view.text = timerFormat((totalDuration - playerPosition).toLong())

                    mHandler.postDelayed(this, 1000)

                    if (playerPosition == totalDuration){

                        next()

                    }
                }
            })

        }else{

            stop()

        }
    }

    fun timerFormat(time : Long) : String {

        val result = String.format("%02d:%02d",
            TimeUnit.SECONDS.toMinutes(time) ,
            TimeUnit.SECONDS.toSeconds(time) - TimeUnit.MINUTES.toSeconds(TimeUnit.SECONDS.toMinutes(time)))

        var convert = " "

        for (i in 0 until result.length)
            convert += result[i]

        return convert
    }

    private fun getSongs(){

        val selection = MediaStore.Audio.Media.IS_MUSIC
        val projection = arrayOf(
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DATA)

        val cursor : Cursor? = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null, null)

        while (cursor!!.moveToNext()){
            musicList.add(Music(
                cursor.getString(0),
                cursor.getString(1),
                cursor.getString(2)))
        }
        cursor.close()

        linearLayoutManager = LinearLayoutManager(this)
        adapter = MusicListAdapter(musicList, this)

        recycler_view.layoutManager = linearLayoutManager
        recycler_view.adapter = adapter


    }

    private fun checkPermissions(){
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED){
            getSongs()
        }else{
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)){
                val appName = getString(R.string.app_name)
                Toast.makeText(this, "$appName needs access to your external storage", Toast.LENGTH_SHORT).show()
            }
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_CODE_READ_EXTERNAL_STORAGE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {

        when (requestCode) {
            REQUEST_CODE_READ_EXTERNAL_STORAGE -> if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getSongs()
            } else {
                Toast.makeText(this, "Permission is not granted", Toast.LENGTH_SHORT).show()
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }
}
