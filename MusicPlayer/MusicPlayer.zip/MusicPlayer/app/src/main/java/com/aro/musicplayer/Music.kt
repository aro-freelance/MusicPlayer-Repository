package com.aro.musicplayer

data class Music(var artistName : String, var songName : String, var songUri : String)